# 📱 BlueTalk — خطوات تحويل HTML إلى APK

## المتطلبات
- Node.js (تنزيل من nodejs.org)
- Android Studio (تنزيل من developer.android.com/studio)
- Java JDK 17+

---

## الخطوات

### 1️⃣ تثبيت الحزم
افتح Terminal أو CMD داخل مجلد المشروع:
```bash
npm install
```

### 2️⃣ إضافة منصة Android
```bash
npx cap add android
```

### 3️⃣ مزامنة الملفات
```bash
npx cap sync android
```

### 4️⃣ فتح المشروع في Android Studio
```bash
npx cap open android
```

### 5️⃣ إضافة صلاحيات البلوتوث في AndroidManifest.xml
افتح الملف:
`android/app/src/main/AndroidManifest.xml`

وأضف هذه السطور قبل `<application`:
```xml
<!-- Bluetooth permissions -->
<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

<!-- BLE feature -->
<uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
```

### 6️⃣ بناء APK
في Android Studio:
- اضغط **Build** من القائمة العلوية
- اختر **Build Bundle(s) / APK(s)**
- اختر **Build APK(s)**
- انتظر حتى ينتهي البناء
- ستجد الـ APK في: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## ⚡ ملاحظات مهمة
- ثبّت التطبيق على **جهازين** مختلفين
- تأكد أن **البلوتوث مفعّل** على كلا الجهازين
- على الجهاز الأول: اضغط **بحث** للعثور على الجهاز الثاني
- اضغط على اسم الجهاز الثاني للاتصال
- ابدأ الدردشة! 🎉

---

## 🔧 استكشاف الأخطاء
- **"البلوتوث غير متاح"** → تأكد من منح صلاحية الموقع والبلوتوث
- **"لم يتم العثور على أجهزة"** → تأكد أن الجهاز الآخر به التطبيق مفتوح
- **"فشل الاتصال"** → قرّب الجهازين من بعض (أقل من 5 أمتار)
